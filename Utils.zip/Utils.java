16:17:07.729 INFO  com.github.kwart.jd.cli.Main - Decompiling Utils.class
import com.apigee.flow.message.MessageContext;
import com.jpmc.apigee.ccb.aes.utils.TemplateString;
import com.jpmc.apigee.ccb.aes.utils.Utils;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.commons.lang.text.StrSubstitutor;

public final class Utils {
  public static Map genericizeMap(Map properties) {
    Map<String, String> map = new HashMap<String, String>();
    Iterator iterator = properties.keySet().iterator();
    while (iterator.hasNext()) {
      Object key = iterator.next();
      Object value = properties.get(key);
      if (key instanceof String && value instanceof String)
        map.put((String)key, (String)value); 
    } 
    return map;
  }
  
  public static String getPropertyValue(MessageContext msgCtxt, String propertyName, Map<String, String> properties) throws IllegalStateException {
    String propertyValue = (String)properties.get(propertyName);
    if (propertyValue != null && !"".equalsIgnoreCase(propertyValue.trim()))
      return resolvePropertyValue(propertyValue, msgCtxt); 
    return null;
  }
  
  public static String resolvePropertyValue(String spec, MessageContext msgCtxt) {
    if (spec.indexOf('{') > -1 && spec.indexOf('}') > -1) {
      TemplateString ts = new TemplateString(spec);
      Map<String, String> valuesMap = new HashMap<String, String>();
      for (String s : ts.variableNames)
        valuesMap.put(s, (String)msgCtxt.getVariable(s)); 
      StrSubstitutor sub = new StrSubstitutor(valuesMap);
      return sub.replace(ts.template);
    } 
    return spec;
  }
}

