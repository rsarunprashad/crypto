16:36:23.812 INFO  com.github.kwart.jd.cli.Main - Decompiling SalesforceAPIAESDecryptionCallout.class
import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.IOIntensive;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;
import com.jpmc.apigee.ccb.aes.utils.SalesforceAPIAESDecryptionCallout;
import com.jpmc.apigee.ccb.aes.utils.Utils;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.exception.ExceptionUtils;

@IOIntensive
public class SalesforceAPIAESDecryptionCallout implements Execution {
  private static final String SHARED_SECRECT_KEY = "shared_secret_key";
  
  private static final String ALGORITHM = "algorithm";
  
  private static final String AES_CRYPTO_ERROR = "aes_crypto_error";
  
  private static final String AES_STACKTRACE = "aes_crypto_stacktrace";
  
  private static final String DEC_HEADERS = "hdrs_for_decrypt";
  
  private static final String DEC_PAYLOAD_FLAG = "dec_payload_flag";
  
  private final Map<String, String> properties;
  
  private String errorDetail;
  
  public SalesforceAPIAESDecryptionCallout(Map properties) {
    this.errorDetail = "";
    this.properties = Utils.genericizeMap(properties);
  }
  
  private Key getKey(MessageContext msgCtxt) throws NoSuchAlgorithmException {
    String keyValue = Utils.getPropertyValue(msgCtxt, "shared_secret_key", this.properties);
    String algorithm = Utils.getPropertyValue(msgCtxt, "algorithm", this.properties);
    return new SecretKeySpec(keyValue.getBytes(), algorithm);
  }
  
  private String decryptText(String encryptedText, MessageContext msgCtxt) throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {
    Key key = getKey(msgCtxt);
    Base64 base64 = new Base64();
    String cryptStr = encryptedText.substring(24);
    byte[] cryptStrByte = base64.decode(cryptStr);
    String cryptIV = encryptedText.substring(0, 23);
    byte[] cryptIVByte = base64.decode(cryptIV);
    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    cipher.init(2, key, new IvParameterSpec(cryptIVByte));
    byte[] decryptedText = cipher.doFinal(cryptStrByte);
    return new String(decryptedText);
  }
  
  private void decryptHeaders(MessageContext msgCtxt) throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {
    String headersToBeDecrypted = (String)msgCtxt.getVariable("hdrs_for_decrypt");
    if (!isNullOrEmpty(headersToBeDecrypted)) {
      String[] encryptionHeadersArr = headersToBeDecrypted.split(",");
      for (String encryptionHeaderName : encryptionHeadersArr) {
        if (!isNullOrEmpty(encryptionHeaderName)) {
          String headerCtx = "request.header." + encryptionHeaderName.trim();
          String cipherText = (String)msgCtxt.getVariable(headerCtx);
          if (!isNullOrEmpty(cipherText))
            msgCtxt.setVariable(headerCtx, decryptText(cipherText, msgCtxt)); 
        } 
      } 
    } 
  }
  
  private void decryptBody(MessageContext msgCtxt) throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {
    String cipherText = (String)msgCtxt.getVariable("request.content");
    if (!isNullOrEmpty(cipherText))
      msgCtxt.setVariable("request.content", decryptText(cipherText, msgCtxt)); 
  }
  
  private void clearVariables(MessageContext msgCtxt) throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {
    msgCtxt.removeVariable("aes_crypto_error");
    msgCtxt.removeVariable("aes_crypto_stacktrace");
  }
  
  public static boolean isNullOrEmpty(String str) {
    if (str != null && str.trim() != "")
      return false; 
    return true;
  }
  
  public ExecutionResult execute(MessageContext msgCtxt, ExecutionContext exeCtxt) {
    try {
      clearVariables(msgCtxt);
      decryptHeaders(msgCtxt);
      String decryptPayloadFlag = Utils.getPropertyValue(msgCtxt, "dec_payload_flag", this.properties);
      if (!isNullOrEmpty(decryptPayloadFlag) && ("Y".equalsIgnoreCase(decryptPayloadFlag.trim().toUpperCase().substring(0, 1)) || "TRUE".equalsIgnoreCase(decryptPayloadFlag.trim().toUpperCase())))
        decryptBody(msgCtxt); 
    } catch (Exception e) {
      msgCtxt.setVariable("aes_crypto_error", "Exception while processing  " + this.errorDetail + e.toString());
      msgCtxt.setVariable("aes_crypto_stacktrace", ExceptionUtils.getStackTrace(e));
      msgCtxt.setVariable("calloutfailure", "failed");
      return ExecutionResult.ABORT;
    } 
    return ExecutionResult.SUCCESS;
  }
}

