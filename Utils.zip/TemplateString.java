16:16:54.472 INFO  com.github.kwart.jd.cli.Main - Decompiling TemplateString.class
import com.jpmc.apigee.ccb.aes.utils.TemplateString;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TemplateString {
  private final Pattern tmpltPattern;
  
  public ArrayList<String> variableNames;
  
  public String template;
  
  private void injectDollar(int position) { this.template = this.template.substring(0, position) + "$" + this.template.substring(position, this.template.length()); }
  
  public TemplateString(String s) {
    this.tmpltPattern = Pattern.compile("\\{([^\\}]+)\\}", 2);
    this.variableNames = new ArrayList();
    examineString(s);
  }
  
  private void examineString(String input) {
    this.template = input;
    int x = 0;
    Matcher m = this.tmpltPattern.matcher(input);
    while (m.find()) {
      this.variableNames.add(m.group(1));
      injectDollar(m.start() + x++);
    } 
  }
}

