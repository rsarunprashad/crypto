16:16:26.751 INFO  com.github.kwart.jd.cli.Main - Decompiling SalesforceAPIAESEncryptionCallout.class
import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.IOIntensive;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.MessageContext;
import com.jpmc.apigee.ccb.aes.utils.SalesforceAPIAESEncryptionCallout;
import com.jpmc.apigee.ccb.aes.utils.Utils;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Map;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.exception.ExceptionUtils;

@IOIntensive
public class SalesforceAPIAESEncryptionCallout implements Execution {
  private static final String SHARED_SECRECT_KEY = "shared_secret_key";
  
  private static final String ALGORITHM = "algorithm";
  
  private static final String AES_CRYPTO_ERROR = "aes_crypto_error";
  
  private static final String AES_STACKTRACE = "aes_crypto_stacktrace";
  
  private static final String ENC_HEADERS = "hdrs_for_encrypt";
  
  private static final String ENC_PAYLOAD_FLAG = "enc_payload_flag";
  
  private final Map<String, String> properties;
  
  public SalesforceAPIAESEncryptionCallout(Map properties) { this.properties = Utils.genericizeMap(properties); }
  
  private Key getKey(MessageContext msgCtxt) throws NoSuchAlgorithmException {
    String keyValue = Utils.getPropertyValue(msgCtxt, "shared_secret_key", this.properties);
    String algorithm = Utils.getPropertyValue(msgCtxt, "algorithm", this.properties);
    return new SecretKeySpec(keyValue.getBytes(), algorithm);
  }
  
  private String getCipherText(String plainText, Key key) throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {
    byte[] iv = new byte[16];
    SecureRandom random = new SecureRandom();
    random.nextBytes(iv);
    IvParameterSpec ivSpec = new IvParameterSpec(iv);
    Base64 base64 = new Base64();
    String ivbase64 = new String(base64.encode(iv));
    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    cipher.init(1, key, ivSpec);
    byte[] encryptedByte = cipher.doFinal(plainText.getBytes());
    String encryptedBase64 = new String(Base64.encodeBase64(encryptedByte));
    return ivbase64 + encryptedBase64;
  }
  
  private void clearVariables(MessageContext msgCtxt) {
    msgCtxt.removeVariable("aes_crypto_error");
    msgCtxt.removeVariable("aes_crypto_stacktrace");
  }
  
  public static boolean isNullOrEmpty(String str) {
    if (str != null && str.trim() != "")
      return false; 
    return true;
  }
  
  public ExecutionResult execute(MessageContext msgCtxt, ExecutionContext exeCtxt) {
    try {
      clearVariables(msgCtxt);
      Key key = getKey(msgCtxt);
      encryptResponseHeaders(msgCtxt, key);
      String encryptPayloadFlag = Utils.getPropertyValue(msgCtxt, "enc_payload_flag", this.properties);
      if (!isNullOrEmpty(encryptPayloadFlag) && ("Y".equalsIgnoreCase(encryptPayloadFlag.toUpperCase().substring(0, 1)) || "TRUE".equalsIgnoreCase(encryptPayloadFlag.toUpperCase())))
        encryptResponsePayload(msgCtxt, key); 
    } catch (Exception e) {
      msgCtxt.setVariable("aes_crypto_error", "Exception " + e.toString());
      msgCtxt.setVariable("aes_crypto_stacktrace", ExceptionUtils.getStackTrace(e));
      return ExecutionResult.ABORT;
    } 
    return ExecutionResult.SUCCESS;
  }
  
  private void encryptResponsePayload(MessageContext msgCtxt, Key key) throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {
    String responseContent = "response.content";
    String content = (String)msgCtxt.getVariable(responseContent);
    if (!isNullOrEmpty(content))
      msgCtxt.setVariable(responseContent, getCipherText(content, key)); 
  }
  
  private void encryptResponseHeaders(MessageContext msgCtxt, Key key) throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {
    String headerNamesForEncryption = Utils.getPropertyValue(msgCtxt, "hdrs_for_encrypt", this.properties);
    if (!isNullOrEmpty(headerNamesForEncryption))
      for (String headerName : headerNamesForEncryption.split(",")) {
        if (!isNullOrEmpty(headerName)) {
          String responseHdr = "response.header." + headerName.trim();
          String headerValue = (String)msgCtxt.getVariable(responseHdr);
          if (!isNullOrEmpty(headerValue)) {
            String cipherText = getCipherText(headerValue, key);
            msgCtxt.setVariable(responseHdr, cipherText);
          } 
        } 
      }  
  }
}

