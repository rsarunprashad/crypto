package com.jpmchase.api.crypto;

public class CryptoEngineFactory {

	public ICryptoEngine getInstance(CryptoType cryptoType, String partnerPubKey) {

		switch (cryptoType) {
		case ECDH_ENC:

			return new ECDHCryptoEngine(partnerPubKey);

		default:
			break;
		}

		return null;
	}

}
