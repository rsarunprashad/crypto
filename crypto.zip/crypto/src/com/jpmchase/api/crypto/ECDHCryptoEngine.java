package com.jpmchase.api.crypto;

import java.security.PublicKey;

public class ECDHCryptoEngine implements ICryptoEngine {
	
	
	private static final String FILE_CHASE_PRIV_KEY="chase-priv-key.pem";
	
	private static final String FILE_CHASE_PUB_KEY="chase-pub-key.pem";

	
	private PublicKey chasePubKey;
	
	private PublicKey chasePrivateKey;
	
	
	private PublicKey partnerPubKey;
	

	
	public ECDHCryptoEngine(String partnerPubKey){
		
		
		
		
		
	}
	
	
	
	
	
	@Override
	public String doEncrypt(String plainText) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String doDecrypt(String cryptoText) {
		// TODO Auto-generated method stub
		return null;
	}





	
	private void loadPublicKey(String publicKeyFile) {
		// TODO Auto-generated method stub
		
	}





	
	private void loadPrivateKey(String privateKeyFile) {
		// TODO Auto-generated method stub
		
	}

}
