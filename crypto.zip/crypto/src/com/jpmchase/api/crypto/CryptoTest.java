package com.jpmchase.api.crypto;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.spec.;

public class CryptoTest {
	
	
	
	
	public static void main(String[] args) {
		String partnerPubKey;
		try {
			partnerPubKey = "";
			
		
			
			ECPublicKeySpec spec =
				      new ECPublicKeySpec(loadKey("partner-pub-key.pem"));
			 KeyFactory kf = KeyFactory.getInstance("EC");
			 kf.generatePublic(spec);
			
			
			ICryptoEngine cryptoEngine= new CryptoEngineFactory().getInstance(CryptoType.ECDH_ENC, partnerPubKey);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static byte[]  loadKey(String fileName) throws IOException, URISyntaxException {
		
	
	return Files.readAllBytes( Paths.get(CryptoTest.class.getClassLoader().getResource(fileName).toURI()));
		
	}

}
