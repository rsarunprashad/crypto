package com.jpmchase.api.crypto;

public interface ICrypto {
	
	
	public String doEncrypt(CryptoType cryptoType, String partnerPubKey,String plainText);
	
	public String doDecrypt(CryptoType cryptoType, String partnerPubKey, String cryptoText);
	
	

}
