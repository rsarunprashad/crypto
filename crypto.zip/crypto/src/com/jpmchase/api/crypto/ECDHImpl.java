package com.jpmchase.api.crypto;

public class ECDHImpl implements ICrypto{

	

	@Override
	public String doEncrypt(CryptoType cryptoType, String partnerPubKey, String plainText) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String doDecrypt(CryptoType cryptoType, String partnerPubKey, String cryptoText) {
		// TODO Auto-generated method stub
		return null;
	}

}
