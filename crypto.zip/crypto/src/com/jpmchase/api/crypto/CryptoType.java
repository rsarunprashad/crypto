package com.jpmchase.api.crypto;

public enum CryptoType {
	
	ECDH_ENC

}
