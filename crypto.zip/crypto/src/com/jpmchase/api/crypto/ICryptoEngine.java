package com.jpmchase.api.crypto;

import java.security.PrivateKey;
import java.security.PublicKey;

public interface ICryptoEngine {

	public String doEncrypt(String plainText);
	
	public String doDecrypt(String cryptoText);
	
	/*
	 * public PublicKey loadPublicKey(String publicKeyFile);
	 * 
	 * public PrivateKey loadPrivateKey(String privateKeyFile);
	 */
		   
	
	
}
